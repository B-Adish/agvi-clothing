const products = [
    {
        id:1,
        name:"Oversized Lavender Tee",
        price:999,
        rating:5,
        image:"https://picsum.photos/400/500?random=11"
    },
    {
        id:2,
        name:"Classic Black Hoodie",
        price:1799,
        rating:4,
        image:"https://picsum.photos/400/500?random=12"
    },
    {
        id:3,
        name:"Premium Cargo Pants",
        price:1499,
        rating:5,
        image:"https://picsum.photos/400/500?random=13"
    },
    {
        id:4,
        name:"Minimal White Shirt",
        price:1299,
        rating:4,
        image:"https://picsum.photos/400/500?random=14"
    }
];

export default products;