import "./NewArrivals.css";
import { FaHeart, FaRegHeart, FaStar } from "react-icons/fa";
import { useState } from "react";
import products from "./products";

function NewArrivals() {

    const [wishlist, setWishlist] = useState([]);

    const toggleWishlist = (id) => {

        if (wishlist.includes(id)) {
            setWishlist(wishlist.filter(item => item !== id));
        } else {
            setWishlist([...wishlist, id]);
        }

    };

    return (

        <section className="new-arrivals">

            <div className="container">

                <div className="section-heading">

                    <h2>New Arrivals</h2>

                    <p>
                        Discover the newest styles carefully selected for you.
                    </p>

                </div>

                <div className="product-grid">

                    {products.map(product => (

                        <div className="product-card" key={product.id}>

                            <div className="product-image">

                                <img
                                    src={product.image}
                                    alt={product.name}
                                />

                                <button
                                    className="wishlist-btn"
                                    onClick={() => toggleWishlist(product.id)}
                                >

                                    {wishlist.includes(product.id)
                                        ? <FaHeart className="heart-red"/>
                                        : <FaRegHeart />
                                    }

                                </button>

                            </div>

                            <div className="product-info">

                                <h3>{product.name}</h3>

                                <div className="rating">

                                    {[...Array(product.rating)].map((_, index) => (

                                        <FaStar key={index} />

                                    ))}

                                </div>

                                <div className="price">

                                    ₹ {product.price}

                                </div>

                                <button className="cart-btn">

                                    Add To Cart

                                </button>

                            </div>

                        </div>

                    ))}

                </div>

            </div>

        </section>

    );

}

export default NewArrivals;