import "./ProductCard.css";
import { Link } from "react-router-dom";
import { FaHeart, FaRegHeart, FaStar } from "react-icons/fa";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";
import { useQuickView } from "../QuickView/QuickViewContext";

function ProductCard({ product }) {
    const { addToCart } = useCart();
    const { wishlistItems, toggleWishlist } = useWishlist();
    const { openQuickView } = useQuickView();

    const isWishlisted = wishlistItems.some(
        (item) => item.id === product.id
    );

    const handleWishlist = (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleWishlist(product);
    };

    const handleCart = (e) => {
        e.preventDefault();
        e.stopPropagation();

        addToCart({
            ...product,
            quantity: 1,
            selectedSize: product.sizes[0],
            selectedColor: product.colors[0]
        });
    };

    return (
        <div className="product-card">
            <div className="badge">{product.badge}</div>

            <button
                className="wishlist-btn"
                onClick={handleWishlist}
            >
                {isWishlisted ? (
                    <FaHeart className="heart-active" />
                ) : (
                    <FaRegHeart />
                )}
            </button>

            <Link
                to={`/product/${product.slug}`}
                className="product-card-link"
            >
                <div className="product-image">
                    <img
                        src={product.images[0]}
                        alt={product.name}
                    />
                </div>
            </Link>

            <button
                className="quick-view-btn"
                onClick={() => openQuickView(product)}
            >
                Quick View
            </button>

            <div className="product-info">
                <div className="rating">
                    <FaStar />
                    <span>{product.rating}</span>
                    <p>({product.reviews})</p>
                </div>

                <Link
                    to={`/product/${product.slug}`}
                    className="product-title"
                >
                    <h3>{product.name}</h3>
                </Link>

                <h2>₹{product.price}</h2>

                <button
                    className="cart-btn"
                    onClick={handleCart}
                >
                    <HiOutlineShoppingBag />
                    <span>Add to Cart</span>
                </button>
            </div>
        </div>
    );
}

export default ProductCard;