import "./QuickView.css";
import { FaTimes, FaStar } from "react-icons/fa";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { Link } from "react-router-dom";
import { useQuickView } from "./QuickViewContext";
import { useCart } from "../../context/CartContext";

function QuickView() {
    const {
        selectedProduct,
        closeQuickView
    } = useQuickView();

    const { addToCart } = useCart();

    if (!selectedProduct) return null;

    const handleAddToCart = () => {
        addToCart({
            ...selectedProduct,
            quantity: 1,
            selectedSize: selectedProduct.sizes[0],
            selectedColor: selectedProduct.colors[0]
        });

        closeQuickView();
    };

    return (
        <div
            className="quickview-overlay"
            onClick={closeQuickView}
        >
            <div
                className="quickview-modal"
                onClick={(e) => e.stopPropagation()}
            >
                <button
                    className="quickview-close"
                    onClick={closeQuickView}
                >
                    <FaTimes />
                </button>

                <div className="quickview-left">
                    <img
                        src={selectedProduct.images[0]}
                        alt={selectedProduct.name}
                    />
                </div>

                <div className="quickview-right">
                    <span className="quickview-badge">
                        {selectedProduct.badge}
                    </span>

                    <h2>{selectedProduct.name}</h2>

                    <div className="quickview-rating">
                        <FaStar />
                        <span>{selectedProduct.rating}</span>
                        <p>({selectedProduct.reviews})</p>
                    </div>

                    <h3>₹{selectedProduct.price}</h3>

                    <p>{selectedProduct.description}</p>

                    <button
                        className="quickview-cart"
                        onClick={handleAddToCart}
                    >
                        <HiOutlineShoppingBag />
                        Add To Cart
                    </button>

                    <Link
                        to={`/product/${selectedProduct.slug}`}
                        className="quickview-details"
                        onClick={closeQuickView}
                    >
                        View Full Details
                    </Link>
                </div>
            </div>
        </div>
    );
}

export default QuickView;