import "../../../../styles/components/cartsummary.css";
import { useCart } from "../../../../context/CartContext";

function CartSummary() {

    const { cartItems } = useCart();

    const subtotal = cartItems.reduce(
        (total, item) => total + item.price * item.quantity,
        0
    );

    const delivery = subtotal > 0 ? 99 : 0;

    const total = subtotal + delivery;

    return (
        <div className="cart-summary">

            <h2>Order Summary</h2>

            <div className="summary-row">
                <span>Subtotal</span>
                <span>₹{subtotal}</span>
            </div>

            <div className="summary-row">
                <span>Delivery</span>
                <span>₹{delivery}</span>
            </div>

            <div className="summary-total">
                <span>Total</span>
                <span>₹{total}</span>
            </div>

            <button className="checkout-btn">
                Proceed to Checkout
            </button>

        </div>
    );

}

export default CartSummary;