import "./ProductInfo.css";
import { useState } from "react";
import { FaStar, FaHeart } from "react-icons/fa";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { useCart } from "../../../../context/CartContext";

function ProductInfo({ product }) {
    const [selectedColor, setSelectedColor] = useState(product.colors[0]);
    const [selectedSize, setSelectedSize] = useState("");
    const [quantity, setQuantity] = useState(1);

    const { addToCart } = useCart();

    return (
        <div className="product-info">

            <span className="product-badge">{product.badge}</span>

            <h1>{product.name}</h1>

            <div className="product-rating">

                <div className="stars">

                    <FaStar />
                    <FaStar />
                    <FaStar />
                    <FaStar />
                    <FaStar />

                </div>

                <span>

                    {product.rating}

                </span>

                <p>

                    ({product.reviews} Reviews)

                </p>

            </div>

            <div className="product-price">
                <h2>₹{product.price}</h2>
                <span>₹{product.originalPrice}</span>
                <small>
                    {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                </small>
            </div>

            <div className="product-option">
                <h4>Color</h4>

                <div className="color-list">
                    {product.colors.map((color) => (
                        <button
                            key={color.name}
                            className={selectedColor.name === color.name ? "color-circle active" : "color-circle"}
                            style={{ backgroundColor: color.code }}
                            onClick={() => setSelectedColor(color)}
                        />
                    ))}
                </div>

                <p className="selected-option">{selectedColor.name}</p>
            </div>

            <div className="product-option">

                <div className="size-header">
                    <h4>Size</h4>

                    <button className="size-guide">
                        Size Guide
                    </button>
                </div>

                <div className="size-list">
                    {product.sizes.map((size) => (
                        <button
                            key={size}
                            className={selectedSize === size ? "size-btn active" : "size-btn"}
                            onClick={() => setSelectedSize(size)}
                        >
                            {size}
                        </button>
                    ))}
                </div>

            </div>

            <div className="product-option">

                <h4>Quantity</h4>

                <div className="quantity-box">

                    <button
                        onClick={() =>
                            quantity > 1 && setQuantity(quantity - 1)
                        }
                    >
                        −
                    </button>

                    <span>{quantity}</span>

                    <button
                        onClick={() => setQuantity(quantity + 1)}
                    >
                        +
                    </button>

                </div>

            </div>

            <div className="action-buttons">

                <button
                    className="cart-btn"
                    onClick={() => {
                        if (!selectedSize) {
                            alert("Please select a size.");
                            return;
                        }

                        addToCart({
                            ...product,
                            selectedSize,
                            selectedColor,
                            quantity
                        });

                        setQuantity(1);

                        alert("Product added to cart.");
                    }}
                >
                    <HiOutlineShoppingBag />
                    Add To Cart
                </button>

                <button className="buy-btn">
                    Buy Now
                </button>

            </div>

            <button className="wishlist-btn-large">
                <FaHeart />
                Add To Wishlist
            </button>

            <div className="delivery-card">
                <div>✓ Free Shipping</div>
                <div>✓ Easy Returns</div>
                <div>✓ Secure Checkout</div>
                <div>✓ Premium Packaging</div>
            </div>

        </div>
    );
}

export default ProductInfo;