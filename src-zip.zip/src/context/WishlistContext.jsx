import { createContext, useContext, useEffect, useState } from "react";

const WishlistContext = createContext();

export function WishlistProvider({ children }) {
    const [wishlistItems, setWishlistItems] = useState(() => {
        const savedWishlist = localStorage.getItem("agvi-wishlist");

        if (!savedWishlist) return [];

        try {
            return JSON.parse(savedWishlist);
        } catch {
            return [];
        }
    });

    const toggleWishlist = (product) => {
        setWishlistItems((currentItems) => {
            const exists = currentItems.some(
                (item) => item.id === product.id
            );

            if (exists) {
                return currentItems.filter(
                    (item) => item.id !== product.id
                );
            }

            return [...currentItems, product];
        });
    };

    const addToWishlist = (product) => {
        setWishlistItems((currentItems) => {
            const exists = currentItems.some(
                (item) => item.id === product.id
            );

            return exists ? currentItems : [...currentItems, product];
        });
    };

    const removeFromWishlist = (id) => {
        setWishlistItems((currentItems) =>
            currentItems.filter((item) => item.id !== id)
        );
    };

    useEffect(() => {
        localStorage.setItem(
            "agvi-wishlist",
            JSON.stringify(wishlistItems)
        );
    }, [wishlistItems]);

    return (
        <WishlistContext.Provider
            value={{
                wishlistItems,
                addToWishlist,
                removeFromWishlist,
                toggleWishlist
            }}
        >
            {children}
        </WishlistContext.Provider>
    );
}

export function useWishlist() {
    return useContext(WishlistContext);
}