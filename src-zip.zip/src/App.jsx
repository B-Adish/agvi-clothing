import AppRoutes from "./routes/AppRoutes";
import QuickView from "./components/QuickView/QuickView";

function App() {

    return (

        <>

            <AppRoutes />

            <QuickView />

        </>

    );

}

export default App;