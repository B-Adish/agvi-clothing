import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "./styles/themes/variables.css";
import "./styles/base/reset.css";
import "./styles/base/global.css";
import { CartProvider } from "./context/CartContext";
import { WishlistProvider } from "./context/WishlistContext";
import { SearchProvider } from "./context/SearchContext";
import { QuickViewProvider } from "./components/QuickView/QuickViewContext";
import { RecentlyViewedProvider } from "./context/RecentlyViewedContext";
import { AuthProvider } from "./context/AuthContext";

import App from "./App.jsx";

createRoot(document.getElementById("root")).render(
    <StrictMode>
        <AuthProvider>
            <RecentlyViewedProvider>
                <QuickViewProvider>
                    <SearchProvider>
                        <WishlistProvider>
                            <CartProvider>
                                <App/>
                            </CartProvider>
                        </WishlistProvider>
                    </SearchProvider>
                </QuickViewProvider>
            </RecentlyViewedProvider>
        </AuthProvider>
    </StrictMode>
);